/********************************** (C) COPYRIGHT *******************************
* File Name          : CompositeKM.C
* Author             : WCH
* Version            : V1.0
* Date               : 2018/08/15
* Description        : CH549模拟USB键鼠复合设备,支持类命令,支持唤醒
                       演示键盘鼠标简单操作。其他键值，参考 HID USAGE TABLE协议文档
                       串口0接收字符：
                       ‘L’：鼠标左键
                       ‘R’: 鼠标右键
                       ‘A’: 键盘‘A’键
                       ‘Q’: 键盘‘Caps’键
                    任意字符：主机睡眠状态下,设备远程唤醒主机（注意设备一般需自供电,因为主机休眠可能USB口也会掉电）
*******************************************************************************/
#include ".\Public\CH549.H"
#include ".\Public\DEBUG.H"
//#define Fullspeed
#ifdef  Fullspeed
#define THIS_ENDP0_SIZE         64
#else
#define THIS_ENDP0_SIZE         8                                              //低速USB，中断传输、控制传输最大包长度为8
#endif
#define ENDP1_IN_SIZE           1                                              //键盘端点数据包大小
UINT8X	Ep0Buffer[MIN(64,THIS_ENDP0_SIZE+2)] _at_ 0x0000;    // OUT&IN,必须是偶地址
UINT8X	Ep1Buffer[MIN(64,ENDP1_IN_SIZE+2)]  _at_ MIN(64,THIS_ENDP0_SIZE+2); 				  // IN,必须是偶地址

UINT8   SetupReq,Ready,UsbConfig;
UINT16  SetupLen;
PUINT8  pDescr;                                                                //USB配置标志
USB_SETUP_REQ   SetupReqBuf;                                                   //暂存Setup包
#define UsbSetupBuf     ((PUSB_SETUP_REQ)Ep0Buffer)
#pragma  NOAREGS
/*设备描述符*/
UINT8C DevDesc[] = { 
    0x12,  // bLength。描述符长度（18字节，十六进制为0x12），就是标志描述符数据结构的长度。
    0x01,  // bDescriptorType。描述符类型。0x01为设备描述符
    0x00,0x02,  // bcdUSB。设备使用的USB协议版本。表示形式0xJJMN版本JJ.M.N（JJ-主要版本号，M-次要版本号，N-次要版本）。
                // 例子：如果是USB2.0，写成：0200H。如果是USB1.1，写成。0110H 如果是USB3.11，写成：0311H。
                // 注意是小端模式，所以低字节写在前面
    0x00,  // bDeviceClass。类代码。表示设备类型。为0时指示用接口描述符来标识类别。详见https://www.usb.org/defined-class-codes
    0x00,  // bDeviceSubClass。子类型。
    0x00,  // bDeviceProtocol。设备使用的协议。
    THIS_ENDP0_SIZE,  // bMaxPackeSize0。端点一次最大传多少个字节。
    0x86,0x1a,  // idVender。厂商ID。
    0xe1,0xe6,  // idProduct。产品ID。
    0x00,0x01,  // bcdDevice。产品版本号。
    0x01,  // iManufacturer。描述厂商的字符串的索引。
    0x02,  // iProduct。描述产品的字符串的索引。
    0x00,  // iSerialNumber。描述产品序列号字符串的索引.
    0x01  // bNumConfigurations。指示设备有多少个配置
    };

/*字符串描述符*/
// 语言ID描述符
UINT8C  MyLangDescr[] = {
    0x04,  // bLength。描述符长度。
    0x03,  // bDescriptorType。描述符类型。语言ID描述符也是字符串描述符，类型为0x03。
    0x09, 0x04  // wLANGID[0]。要支持的语言ID号。
    // wLANGID[n]。有可能会支持多种语言。但是这里没写了。
    };
// 厂家信息描述符
UINT8C  MyManuInfo[] = {
    0x0E,  // bLength。描述符长度。
    0x03,  // bDescriptorType。描述符类型。字符串描述符类型为0x03。
    'C', 0, 'S', 0, 'Y', 0, '.', 0, 'U', 0, 'S', 0, 'B', 0  // bString。UNICODE编码的字符串。
    };
// 产品信息描述符
UINT8C  MyProdInfo[] = {
    0x0C,  // bLength。描述符长度。
    0x03,  // bDescriptorType。描述符类型。字符串描述符类型为0x03。
    'A', 0, 'u', 0, 'd', 0, 'i', 0, 'o', 0  // bString。UNICODE编码的字符串。
    };

/*HID类报表描述符*/
UINT8C ConsumerRepDesc[] =
{
    0x05,0x0C,  // Usage Page (Consumer)
    0x09,0x01,  // Usage(Consumer Control)
    0xA1,0x01,  // Collection (Application),                Main Items —— Collection —— Application
        0x15,0x00,  // Logical Minimum (0),                     Global Items —— Logical Minimum —— 0
        0x25,0x01,  // Logical Maximum (1),                     Global Items —— Logical Maximum —— 1
        0x75,0x01,  // Report Size (1),                         Global Items —— Report Size —— 1
        0x95,0x01,  // Report Count (1),                        Global Items —— Report Count —— 1

        0x09,0xCD,  // Usage(Play/Pause),开始暂停
        0x81,0x06,  // Input (Data, Value, Relative),
        0x09,0xB5,  // Usage(Scan Next Track),下一曲
        0x81,0x06,  // Input (Data, Value, Relative),
        0x09,0xB6,  // Usage(Scan Previous Track),上一曲
        0x81,0x06,  // Input (Data, Value, Relative),
        0x09,0xE2,  // Usage(Mute),静音
        0x81,0x06,  // Input (Data, Value, Relative),
        0x09,0xE9,  // Usage(Volume Increment),音量+
        0x81,0x06,  // Input (Data, Value, Relative),
        0x09,0xEA,  // Usage(Volume Decrement),音量-
        0x81,0x06,  // Input (Data, Value, Relative),

        0x75,0x01,  // Report Size (1),                         Global Items —— Report Size —— 1
        0x95,0x02,  // Report Count (2),
        0x81,0x01,  // Input (Constant),                        Main Items —— Input —— Constant
    0xC0  // End Collection,                                Main Items —— End Collection
};

/*配置描述符集合（必须按照顺序）*/
UINT8C CfgDesc[] =
{
    // 标准配置描述符
    0x09,  // bLength。配置本描述符的长度。
    0x02,  // bDescriptorType。描述符类型。配置描述符为0x02。
    0x3b,0x00,  // wTotalLength。配置描述符集合总长度。
    0x01,  // bNumInterfaces。当前配置下面有多少个接口。
    0x01,  // bConfigurationValue。当前配置的标识。一个USB设备可能有多个配置，但是当前只能选择一种配置。
    0x00,  // iConfiguration。描述该配置的字符串的索引值。如果没有字符串，那这个值就是0。
    0xE0,  // bmAttributes。在这个配置下，设备的一些特性。
                // D7是保留位，默认为1；
                // D6表示供电方式，0是自供电，1是总线供电；
                // D5表示是否支持远程唤醒，为1表示设备支持远程唤醒；
                // D4~D0保留，默认为0。
    0x32,  // bMaxPower。配置设备需要的电流。单位是2ma。如果一个设备耗电量100ma，那么本字节设置为0x32即可。

    // 接口描述符(Consumer)
    0x09,  // bLength。配置本描述符的长度。
    0x04,  // bDescriptorType。描述符类型。接口描述符为0x04。
    0x00,  // bInterfaceNumber。接口编号。如果一个配置有多个接口的话，那么每个接口的编号都有一个独立的编号，编号从0开始递增。
    0x00,  // bAlternateSetting。备用接口编号。一般很少用，设置为0。
    0x01,  // bNumEndpoints。该接口使用的端点个数。
    0x03,  // bInterfaceClass。接口类。当设备描述符设备类型bDeviceClass为0时，也就是指示用接口描述符来标识类别。
    0x01,  // bInterfaceSubClass。接口子类。
    0x01,  // bInterfaceProtocol。接口协议。
    0x00,  // iInterface。此接口的字符串索引值。没有的话一般为0.
    
    // HID类描述符
    0x09,  // bLength。配置本描述符的长度。
    0x21,  // bDescriptorType。描述符类型。HID描述符为0x21。
    0x11,0x01,  // bcdHID。HID设备所遵循的HID版本号，为4位16进制的BCD码。1.0即0x0100，1.1即0x0101，2.0即0x0200。
    0x00,  // bCountryCode。HID设备国家/地区代码。
    0x01,  // bNumDescriptor。HID设备支持的下级描述符的数量。由于HID设备至少需要包括一个报告描述符，故其值至小为0x01，一般的HID设备也为1，也就是有一个报告描述符，物理描述符很少用到。
    0x22,  // bDescriptorTyep。下级描述符的类型。下级描述符第1个必须是报告描述符，所以这里存放报告描述符类型，报告描述符的类型为0x22。
    sizeof(ConsumerRepDesc)&0xFF,sizeof(ConsumerRepDesc)>>8,  // wDescriptorLength。下级描述符的长度
    
    // 端点描述符(Consumer)
    0x07,  // bLength。配置本描述符的长度。
    0x05,  // bDescriptorType。描述符类型。端点描述符为0x05。
    0x81,  // bEndpointAddress。
                // Bit 3…0: 端点编号；
                // Bit 6…4: 保留，默认为0；
                // Bit 7:如果是控制端点可以忽略，因为控制端点有两个方向，否则一般表示数据传输方向，0 = OUT endpoint   1 = IN endpoint。 
    0x03,  // bmAttributes。Bits 1..0: 表示传输类型
                // 00 = Control-控制传输
                // 01 = Isochronous-同步传输
                // 10 = Bulk-批量传输
                // 11 = Interrupt-中断传输
                // Bits 7..2: 还没讲
    ENDP1_IN_SIZE,0x00,  // wMaxPackeSize（双字节）。表示当前配置下此端点能够接收或发送的最大数据包的大小。
    0x0a  // bInterval。查询时间。就是主机多久和设备通讯一次。低速和全速称为帧，一个值代表1ms。高速称为微帧，一个值代表125us。
};

/*键盘数据*/
UINT8 HIDKey[ENDP1_IN_SIZE];

UINT8 Endp1Busy = 0;                                                 //传输完成控制标志位
UINT8 Endp2Busy = 0;
UINT8 WakeUpEnFlag = 0;                                              //远程唤醒使能标志
/*******************************************************************************
* Function Name  : CH554USBDevWakeup()
* Description    : CH554设备模式唤醒主机，发送K信号
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CH554USBDevWakeup( )
{
#ifdef Fullspeed
    UDEV_CTRL |= bUD_LOW_SPEED;
    mDelaymS(2);
    UDEV_CTRL &= ~bUD_LOW_SPEED;
#else
    UDEV_CTRL &= ~bUD_LOW_SPEED;
    mDelaymS(2);
    UDEV_CTRL |= bUD_LOW_SPEED;
#endif
}
/*******************************************************************************
* Function Name  : USBDeviceInit()
* Description    : USB设备模式配置,设备模式启动，收发端点配置，中断开启
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USBDeviceInit()
{
    IE_USB = 0;
    USB_CTRL = 0x00;                                                           // 先设定USB设备模式
    UDEV_CTRL = bUD_PD_DIS;                                                    // 禁止DP/DM下拉电阻
#ifndef Fullspeed
    UDEV_CTRL |= bUD_LOW_SPEED;                                                //选择低速1.5M模式
    USB_CTRL |= bUC_LOW_SPEED;
#else
    UDEV_CTRL &= ~bUD_LOW_SPEED;                                               //选择全速12M模式，默认方式
    USB_CTRL &= ~bUC_LOW_SPEED;
#endif
    UEP1_T_LEN = 0;                                                            //预使用发送长度一定要清空
    UEP2_T_LEN = 0;                                                            //预使用发送长度一定要清空
    UEP0_DMA = Ep0Buffer;                                                      //端点0数据传输地址
    UEP4_1_MOD &= ~(bUEP4_RX_EN | bUEP4_TX_EN);                                //端点0单64字节收发缓冲区
    UEP1_DMA = Ep1Buffer;                                                      //端点1数据传输地址
    UEP4_1_MOD = UEP4_1_MOD & ~bUEP1_BUF_MOD | bUEP1_TX_EN;                    //端点1发送使能 64字节缓冲区
    USB_DEV_AD = 0x00;
    USB_CTRL |= bUC_DEV_PU_EN | bUC_INT_BUSY | bUC_DMA_EN;                     // 启动USB设备及DMA，在中断期间中断标志未清除前自动返回NAK
    UDEV_CTRL |= bUD_PORT_EN;                                                  // 允许USB端口
    USB_INT_FG = 0xFF;                                                         // 清中断标志
    USB_INT_EN = bUIE_SUSPEND | bUIE_TRANSFER | bUIE_BUS_RST;
    IE_USB = 1;
}
/*******************************************************************************
* Function Name  : Enp1IntIn
* Description    : USB设备模式端点1的中断上传
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Enp1IntIn( UINT8 *buf,UINT8 len )
{
    memcpy( Ep1Buffer, buf, len );                                            //加载上传数据
    UEP1_T_LEN = len;                                                         //上传数据长度
    UEP1_CTRL = UEP1_CTRL & ~ MASK_UEP_T_RES | UEP_T_RES_ACK;                 //有数据时上传数据并应答ACK
}
/*******************************************************************************
* Function Name  : DeviceInterrupt()
* Description    : CH559USB中断处理函数
*******************************************************************************/
void DeviceInterrupt( void ) interrupt INT_NO_USB using 1                    //USB中断服务程序,使用寄存器组1
{
    UINT16 len = 0;
    if(UIF_TRANSFER)                                                            //USB传输完成标志
    {
        switch (USB_INT_ST & (MASK_UIS_TOKEN | MASK_UIS_ENDP))
        {
        case UIS_TOKEN_IN | 2:                                                  //endpoint 2# 中断端点上传
            UEP2_T_LEN = 0;                                                     //预使用发送长度一定要清空
            UEP2_CTRL ^= bUEP_T_TOG;                                          //手动翻转
            Endp2Busy = 0;
            UEP2_CTRL = UEP2_CTRL & ~ MASK_UEP_T_RES | UEP_T_RES_NAK;           //默认应答NAK
            break;
        case UIS_TOKEN_IN | 1:                                                  //endpoint 1# 中断端点上传
            UEP1_T_LEN = 0;                                                     //预使用发送长度一定要清空
            UEP1_CTRL ^= bUEP_T_TOG;                                          //手动翻转
            Endp1Busy = 0;
            UEP1_CTRL = UEP1_CTRL & ~ MASK_UEP_T_RES | UEP_T_RES_NAK;           //默认应答NAK
            break;
        case UIS_TOKEN_SETUP | 0:                                               //SETUP事务
            UEP0_CTRL = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;           //预置NAK,防止stall之后不及时清除响应方式
            len = USB_RX_LEN;
            if(len == (sizeof(USB_SETUP_REQ)))
            {
                SetupLen = ((UINT16)UsbSetupBuf->wLengthH<<8) + UsbSetupBuf->wLengthL;
                len = 0;                                                        // 默认为成功并且上传0长度
                SetupReq = UsbSetupBuf->bRequest;
                if ( ( UsbSetupBuf->bRequestType & USB_REQ_TYP_MASK ) != USB_REQ_TYP_STANDARD )/* HID类命令 */
                {
                    switch( SetupReq )
                    {
                    case 0x01://GetReport
                        break;
                    case 0x02://GetIdle
                        break;
                    case 0x03://GetProtocol
                        break;
                    case 0x09://SetReport
                        break;
                    case 0x0A://SetIdle
                        break;
                    case 0x0B://SetProtocol
                        break;
                    default:
                        len = 0xFFFF;                                  /*命令不支持*/
                        break;
                    }
                }
                else
                {
                    //标准请求
                    switch(SetupReq)                                        //请求码
                    {
                    case USB_GET_DESCRIPTOR:
                        switch(UsbSetupBuf->wValueH)
                        {
                        case 1:                                             //设备描述符
                            pDescr = DevDesc;                               //把设备描述符送到要发送的缓冲区
                            len = sizeof(DevDesc);
                            break;
                        case 2:                                             //配置描述符
                            pDescr = CfgDesc;                               //把设备描述符送到要发送的缓冲区
                            len = sizeof(CfgDesc);
                            break;
                        case 3:
                            switch( UsbSetupBuf->wValueL )
                            {
                            case 1:
                                pDescr = (PUINT8)( &MyManuInfo[0] );
                                len = sizeof( MyManuInfo );
                                break;
                            case 2:
                                pDescr = (PUINT8)( &MyProdInfo[0] );
                                len = sizeof( MyProdInfo );
                                break;
                            case 0:
                                pDescr = (PUINT8)( &MyLangDescr[0] );
                                len = sizeof( MyLangDescr );
                                break;
                            default:
                                len = 0xFFFF;                           // 不支持的字符串描述符
                                break;
                            }
                            break;
                        case 0x22:                                          //报表描述符
                            if(UsbSetupBuf->wIndexL == 0)                   //接口0报表描述符
                            {
                                pDescr = ConsumerRepDesc;                        //数据准备上传
                                len = sizeof(ConsumerRepDesc);
                            }
                            else
                            {
                                len = 0xFFFF;                                 //本程序只有1个接口，这句话正常不可能执行
                            }
                            break;
                        default:
                            len = 0xFFFF;                                     //不支持的命令或者出错
                            break;
                        }
                        if ( SetupLen > len )
                        {
                            SetupLen = len;    //限制总长度
                        }
                        len = SetupLen >= THIS_ENDP0_SIZE ? THIS_ENDP0_SIZE : SetupLen; //本次传输长度
                        memcpy(Ep0Buffer,pDescr,len);                        //加载上传数据
                        SetupLen -= len;
                        pDescr += len;
                        break;
                    case USB_SET_ADDRESS:
                        SetupLen = UsbSetupBuf->wValueL;                     //暂存USB设备地址
                        break;
                    case USB_GET_CONFIGURATION:
                        Ep0Buffer[0] = UsbConfig;
                        if ( SetupLen >= 1 )
                        {
                            len = 1;
                        }
                        break;
                    case USB_SET_CONFIGURATION:
                        UsbConfig = UsbSetupBuf->wValueL;
                        if(UsbConfig)
                        {
#ifdef DE_PRINTF
                            printf("SET CONFIG.\n");
#endif
                            Ready = 1;                                                   //set config命令一般代表usb枚举完成的标志
                        }
                        break;
                    case 0x0A:
                        break;
                    case USB_CLEAR_FEATURE:                                              //Clear Feature
                        if ( ( UsbSetupBuf->bRequestType & USB_REQ_RECIP_MASK ) == USB_REQ_RECIP_ENDP )// 端点
                        {
                            switch( UsbSetupBuf->wIndexL )
                            {
                            case 0x82:
                                UEP2_CTRL = UEP2_CTRL & ~ ( bUEP_T_TOG | MASK_UEP_T_RES ) | UEP_T_RES_NAK;
                                break;
                            case 0x81:
                                UEP1_CTRL = UEP1_CTRL & ~ ( bUEP_T_TOG | MASK_UEP_T_RES ) | UEP_T_RES_NAK;
                                break;
                            case 0x01:
                                UEP1_CTRL = UEP1_CTRL & ~ ( bUEP_R_TOG | MASK_UEP_R_RES ) | UEP_R_RES_ACK;
                                break;
                            default:
                                len = 0xFFFF;                                            // 不支持的端点
                                break;
                            }
                        }
                        if ( ( UsbSetupBuf->bRequestType & USB_REQ_RECIP_MASK ) == USB_REQ_RECIP_DEVICE )// 设备
                        {
                            WakeUpEnFlag = 0;
                            printf("Wake up\n");
                            break;
                        }
                        else
                        {
                            len = 0xFFFF;                                                // 不是端点不支持
                        }
                        break;
                    case USB_SET_FEATURE:                                               /* Set Feature */
                        if( ( UsbSetupBuf->bRequestType & 0x1F ) == 0x00 )              /* 设置设备 */
                        {
                            if( ( ( ( UINT16 )UsbSetupBuf->wValueH << 8 ) | UsbSetupBuf->wValueL ) == 0x01 )
                            {
                                if( CfgDesc[ 7 ] & 0x20 )
                                {
                                    WakeUpEnFlag = 1;                                   /* 设置唤醒使能标志 */
                                    printf("Enable Remote Wakeup.\n");
                                }
                                else
                                {
                                    len = 0xFFFF;                                        /* 操作失败 */
                                }
                            }
                            else
                            {
                                len = 0xFFFF;                                            /* 操作失败 */
                            }
                        }
                        else if( ( UsbSetupBuf->bRequestType & 0x1F ) == 0x02 )        /* 设置端点 */
                        {
                            if( ( ( ( UINT16 )UsbSetupBuf->wValueH << 8 ) | UsbSetupBuf->wValueL ) == 0x00 )
                            {
                                switch( ( ( UINT16 )UsbSetupBuf->wIndexH << 8 ) | UsbSetupBuf->wIndexL )
                                {
                                case 0x82:
                                    UEP2_CTRL = UEP2_CTRL & (~bUEP_T_TOG) | UEP_T_RES_STALL;/* 设置端点2 IN STALL */
                                    break;
                                case 0x02:
                                    UEP2_CTRL = UEP2_CTRL & (~bUEP_R_TOG) | UEP_R_RES_STALL;/* 设置端点2 OUT Stall */
                                    break;
                                case 0x81:
                                    UEP1_CTRL = UEP1_CTRL & (~bUEP_T_TOG) | UEP_T_RES_STALL;/* 设置端点1 IN STALL */
                                    break;
                                default:
                                    len = 0xFFFF;                               //操作失败
                                    break;
                                }
                            }
                            else
                            {
                                len = 0xFFFF;                                   //操作失败
                            }
                        }
                        else
                        {
                            len = 0xFFFF;                                      //操作失败
                        }
                        break;
                    case USB_GET_STATUS:
                        Ep0Buffer[0] = 0x00;
                        Ep0Buffer[1] = 0x00;
                        if ( SetupLen >= 2 )
                        {
                            len = 2;
                        }
                        else
                        {
                            len = SetupLen;
                        }
                        break;
                    default:
                        len = 0xFFFF;                                           //操作失败
                        break;
                    }
                }
            }
            else
            {
                len = 0xFFFF;                                                   //包长度错误
            }
            if(len == 0xFFFF)
            {
                SetupReq = 0xFF;
                UEP0_CTRL = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;//STALL
            }
            else if(len)                                                //上传数据或者状态阶段返回0长度包
            {
                UEP0_T_LEN = len;
                UEP0_CTRL = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;//默认数据包是DATA1，返回应答ACK
            }
            else
            {
                UEP0_T_LEN = 0;  //虽然尚未到状态阶段，但是提前预置上传0长度数据包以防主机提前进入状态阶段
                UEP0_CTRL = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;//默认数据包是DATA1,返回应答ACK
            }
            break;
        case UIS_TOKEN_IN | 0:                                               //endpoint0 IN
            switch(SetupReq)
            {
            case USB_GET_DESCRIPTOR:
                len = SetupLen >= THIS_ENDP0_SIZE ? THIS_ENDP0_SIZE : SetupLen;    //本次传输长度
                memcpy( Ep0Buffer, pDescr, len );                            //加载上传数据
                SetupLen -= len;
                pDescr += len;
                UEP0_T_LEN = len;
                UEP0_CTRL ^= bUEP_T_TOG;                                     //同步标志位翻转
                break;
            case USB_SET_ADDRESS:
                USB_DEV_AD = USB_DEV_AD & bUDA_GP_BIT | SetupLen;
                UEP0_CTRL = UEP_R_RES_ACK | UEP_T_RES_NAK;
                break;
            default:
                UEP0_T_LEN = 0;                                              //状态阶段完成中断或者是强制上传0长度数据包结束控制传输
                UEP0_CTRL = UEP_R_RES_ACK | UEP_T_RES_NAK;
                break;
            }
            break;
        case UIS_TOKEN_OUT | 0:  // endpoint0 OUT
            len = USB_RX_LEN;
            if(SetupReq == 0x09)
            {
                if(Ep0Buffer[0])
                {
                    printf("Light on Num Lock LED!\n");
                }
                else if(Ep0Buffer[0] == 0)
                {
                    printf("Light off Num Lock LED!\n");
                }
            }
            UEP0_CTRL ^= bUEP_R_TOG;                                      //同步标志位翻转
            break;
        default:
            break;
        }
        UIF_TRANSFER = 0;                                                 //写0清空中断
    }
    else if(UIF_BUS_RST)                                                  //设备模式USB总线复位中断
    {
        UEP0_CTRL = UEP_R_RES_ACK | UEP_T_RES_NAK;
        UEP1_CTRL = UEP_T_RES_NAK;
        UEP2_CTRL = UEP_T_RES_NAK;
        USB_DEV_AD = 0x00;
        UIF_SUSPEND = 0;
        UIF_TRANSFER = 0;
        Ready = 0;
        UIF_BUS_RST = 0;                                                 //清中断标志
    }
    else if (UIF_SUSPEND)                                                           //USB总线挂起/唤醒完成
    {
        UIF_SUSPEND = 0;
        if ( USB_MIS_ST & bUMS_SUSPEND )                                            //挂起
        {
#ifdef DE_PRINTF
            printf( "z" );                                                          //睡眠状态
#endif
//             while ( XBUS_AUX & bUART0_TX )
//             {
//                 ;    //等待发送完成
//             }
//             SAFE_MOD = 0x55;
//             SAFE_MOD = 0xAA;
//             WAKE_CTRL = bWAK_BY_USB | bWAK_RXD0_LO;                              //USB或者RXD0有信号时可被唤醒
//             PCON |= PD;                                                          //睡眠
//             SAFE_MOD = 0x55;
//             SAFE_MOD = 0xAA;
//             WAKE_CTRL = 0x00;
        }
        else                                                                        // 唤醒
        {
#ifdef DE_PRINTF
            printf( "w" );
#endif
        }
    }
    else {                                                                          //意外的中断,不可能发生的情况
        USB_INT_FG = 0xFF;                                                          //清中断标志
#ifdef DE_PRINTF
        printf("UnknownInt  \n");
#endif
    }
}
void HIDValueHandle()
{
    UINT8 i;
    i = _getkey( );
    printf( "%c", (UINT8)i );
    if( WakeUpEnFlag )                                                   //主机已休眠
    {
        CH554USBDevWakeup();                                             //唤醒主机
    }
    else
    {
        switch(i)
        {
        //数据上传示例
        case 'p':                                                         //p键
            HIDKey[0] |= 0x01;                                             //按键开始
            while( Endp1Busy )
            {
                ;    //如果忙（上一包数据没有传上去），则等待。
            }
            Endp1Busy = 1;                                               //设置为忙状态
            Enp1IntIn(HIDKey,sizeof(HIDKey));
            HIDKey[0] = 0x00;  // 清零
            break;
        case 'n':                                                         //n键
            HIDKey[0] |= 0x02;                                             //按键开始
            while( Endp1Busy )
            {
                ;    //如果忙（上一包数据没有传上去），则等待。
            }
            Endp1Busy = 1;                                               //设置为忙状态
            Enp1IntIn(HIDKey,sizeof(HIDKey));
            HIDKey[0] = 0x00;  // 清零
            break;
        case 'l':                                                         //l键
            HIDKey[0] |= 0x04;                                             //按键开始
            while( Endp1Busy )
            {
                ;    //如果忙（上一包数据没有传上去），则等待。
            }
            Endp1Busy = 1;                                               //设置为忙状态
            Enp1IntIn(HIDKey,sizeof(HIDKey));
            HIDKey[0] = 0x00;  // 清零
            break;
        case 'm':                                                         //m键
            HIDKey[0] |= 0x08;                                             //按键开始
            while( Endp1Busy )
            {
                ;    //如果忙（上一包数据没有传上去），则等待。
            }
            Endp1Busy = 1;                                               //设置为忙状态
            Enp1IntIn(HIDKey,sizeof(HIDKey));
            HIDKey[0] = 0x00;  // 清零
            break;
        case '+':                                                         //+键
            HIDKey[0] |= 0x10;                                             //按键开始
            while( Endp1Busy )
            {
                ;    //如果忙（上一包数据没有传上去），则等待。
            }
            Endp1Busy = 1;                                               //设置为忙状态
            Enp1IntIn(HIDKey,sizeof(HIDKey));
            HIDKey[0] = 0x00;  // 清零
            break;
        case '-':                                                         //-键
            HIDKey[0] |= 0x20;                                             //按键开始
            while( Endp1Busy )
            {
                ;    //如果忙（上一包数据没有传上去），则等待。
            }
            Endp1Busy = 1;                                               //设置为忙状态
            Enp1IntIn(HIDKey,sizeof(HIDKey));
            HIDKey[0] = 0x00;  // 清零
            break;
        default:                                                          //其他
            break;
        }
    }
}
void main()
{
    CfgFsys( );                                                           //CH549时钟选择配置
    mDelaymS(20);                                                         //修改主频等待内部晶振稳定,必加
    mInitSTDIO( );                                                        //串口0初始化
    printf("KM Device start ...\n");
    USBDeviceInit();                                                      //USB设备模式初始化
    EA = 1;                                                               //允许单片机中断
    memset(HIDKey,0,sizeof(HIDKey));                                      //清空缓冲区
    while(1)
    {
        if(Ready)
        {
            HIDValueHandle();                                             //串口0,程序会停在getkey函数等待接收一个字符
        }
    }
}


