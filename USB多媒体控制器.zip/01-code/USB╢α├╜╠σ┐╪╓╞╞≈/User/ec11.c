#include "ec11.h"


volatile EC11Struct EC11;

void EC11StructInit()
{
    EC11.NewEventFlag = 0;
    EC11.PushButtonDownEvent = 0;
    EC11.ClockwiseEvent = 0;
    EC11.AntiClockwiseEvent = 0;
}

void EC11Init()
{
    EC11StructInit();
    
    GPIO_Init( PORT3,PIN2,MODE3);                                              //P32(INT0)上拉输入
    GPIO_Init( PORT3,PIN3,MODE3);                                              //P33(INT1)上拉输入
    GPIO_Init( PORT3,PIN7,MODE3);                                              //P37(INT3)上拉输入
    GPIO_INT_Init((INT_INT0_L|INT_INT1_L),INT_EDGE,Enable); //外部中断配置
}



