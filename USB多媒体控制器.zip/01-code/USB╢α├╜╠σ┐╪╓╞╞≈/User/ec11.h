#ifndef _EC11_
#define _EC11_

#include ".\GPIO\GPIO.H"

typedef struct
{
    UINT8 NewEventFlag;
    UINT8 PushButtonDownEvent;
    UINT8 ClockwiseEvent;
    UINT8 AntiClockwiseEvent;
}EC11Struct;

extern volatile EC11Struct EC11;

extern void EC11Init();

#endif